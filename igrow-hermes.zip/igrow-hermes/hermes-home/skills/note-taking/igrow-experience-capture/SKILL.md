---
name: igrow-experience-capture
description: Use when user cerita incident/lesson kerja ke wiki iGROW.
---

# iGROW Experience Capture

Capture a user's work story (incident, lesson, reflection) into the iGROW wiki. Project files `igrow/SCHEMA.md` and `igrow/project-skills/capture-experience.md` are the source of truth — read them first every session; this skill only adds patterns proven in practice.

## Workflow

1. **Read before writing**: `igrow/SCHEMA.md`, `igrow/project-skills/capture-experience.md`, `igrow/_index.md`.
2. **Find active career**: `igrow/wiki/careers/*/about.md` with no end date. If NO career exists, ask the user before creating one — never guess the binding.
3. **Redact FIRST, before anything is written**: client names, internal IPs, hostnames, usernames, credentials. Check the career's `about.md` for the established anonymization convention (e.g. "bank nasional (anonim)") and reuse it for consistency.
4. **Write the page triple** (per story, as applicable):
   - Incident → `careers/career-N/knowledge/incidents/YYYY-MM-slug.md` — body: Symptom / Investigation / Finding / Action / Result / Lesson Learned.
   - Lesson → `careers/career-N/lessons-learned/slug.md`.
   - Knowledge → `careers/career-N/knowledge/slug.md` — only for a genuinely reusable tool/command reference (don't invent filler pages).
   - All cross-linked with dual-link See Also format per SCHEMA.
5. **Update `careers/career-N/skills.md`** — add/extend skill rows with `[[links]]` as evidence.
6. **Mandatory close-out (SCHEMA)**: update `igrow/wiki/_index.md`, master `igrow/_index.md` (keep Total pages count accurate), append `igrow/log.md` with `## [YYYY-MM-DD] ingest | subjek`. Batch these as parallel tool calls.

## Pitfalls (proven)

- **Credential leak in chat**: if the user's story contains a real password/API key, STOP before writing. Warn the user the secret is now in chat history and should be rotated as compromised. Ask explicit consent to record with full redaction. Write only the *pattern* of the incident, never the credential, and note in Referensi that sensitive data was intentionally omitted.
- **Story contradicts an existing lesson**: do NOT overwrite or silently pick one. Clarify the context difference with the user first (terjadwal vs manual, window vs jam operasional). Then create the new lesson AND add `contradictions: [other-slug]` to BOTH pages' frontmatter, with a sentence in each explaining why both are valid in their context. Contradictions are complementary knowledge, not errors.
- **Same alert signal, different root cause**: when a new incident shares a symptom with prior ones (e.g. 3rd "CPU tinggi" alert), explicitly cross-link to the earlier incidents/lessons and, at 3+ occurrences, add a comparison table (signal → cause → action) to the newest lesson. That's what turns incidents into a playbook.
- **Add preventive insight, don't just transcribe**: each lesson should include a pencegahan/mitigasi section the user didn't necessarily state (e.g. `SystemMaxUse` for journald, `nice`/`ionice` for manual backup, `MemoryMax=`/`OOMScoreAdjust=` for OOM, alert suppression in maintenance windows). Label it as an added recommendation.
- **Report format to user**: after capture, reply concisely in Indonesian with: what was written (paths), what was redacted, one highlighted takeaway, and current wiki totals. Don't re-narrate the whole story back.
- See `references/incident-patterns.md` for the symptom→cause→action taxonomy collected so far.

## Language

All wiki content and user-facing replies in Indonesian (Bahasa Indonesia), matching the project's existing convention.
